# Hovers and focus using the has() relational pseudo-class

A Pen created on CodePen.io. Original URL: [https://codepen.io/utilitybend/pen/bGvjLba](https://codepen.io/utilitybend/pen/bGvjLba).

Hovers and focus using the has() relational pseudo-class can give a boost to a11y